class Category:





def create_spend_chart(categories):
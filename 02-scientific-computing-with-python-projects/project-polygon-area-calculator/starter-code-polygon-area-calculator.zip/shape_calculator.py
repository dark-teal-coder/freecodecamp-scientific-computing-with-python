class Rectangle:




class Square:

def add_time(start, duration):





    return new_time